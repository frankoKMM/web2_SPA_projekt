<template>
  <h1>This is the Home page</h1>
  <h3>Use the navigation bar in the header to look around!</h3>
</template>
