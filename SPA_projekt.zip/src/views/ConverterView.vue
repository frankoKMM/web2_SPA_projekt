<template>
  <div>
    <h2>Distance converter</h2>
    <div class="container-fluid p-2 d-flex justify-content-center">
      <converter></converter>
    </div>
  </div>
</template>
