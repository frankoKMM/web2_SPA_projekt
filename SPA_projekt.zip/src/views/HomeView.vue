<template>
  <div>
    <home></home>
  </div>
</template>
